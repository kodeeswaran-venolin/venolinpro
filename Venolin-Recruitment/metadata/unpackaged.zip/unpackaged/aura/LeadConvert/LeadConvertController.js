({
	doInit : function(component, event, helper) {
		helper.leadUpdate(component, event, helper);
	}
})